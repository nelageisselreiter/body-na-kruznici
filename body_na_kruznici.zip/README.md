# 🔵 Body na kružnici

Webová aplikace ve Streamlitu, která vykreslí body na kružnici podle zadaných parametrů.
